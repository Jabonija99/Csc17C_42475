/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   GenStringFunct.h
 * Author: K99
 *
 * Created on June 2, 2018, 5:27 PM
 */

#ifndef GENSTRINGFUNCT_H
#define GENSTRINGFUNCT_H

#include <cstdlib>
#include <string>

//typedef std::string (*genfunction)(int);

std::string genString(int size);

#endif /* GENSTRINGFUNCT_H */

