/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Customer.h
 * Author: K99
 *
 * Created on June 5, 2018, 1:34 AM
 */

#ifndef CUSTOMER_H
#define CUSTOMER_H

struct customer{
    int index;
};


#endif /* CUSTOMER_H */

