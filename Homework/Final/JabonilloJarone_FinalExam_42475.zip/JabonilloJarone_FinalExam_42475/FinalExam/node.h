/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   node.h
 * Author: K99
 *
 * Created on May 24, 2018, 12:22 AM
 */

#ifndef NODE_H
#define NODE_H

struct node{
    int data;
    node *left;
    node *right;
};


#endif /* NODE_H */

